@echo off
:: Check for admin privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process '%~dp0start_actual.bat' -Verb RunAs"
    exit /b
)

:: If already admin, run the actual script
call "%~dp0start_actual.bat"
